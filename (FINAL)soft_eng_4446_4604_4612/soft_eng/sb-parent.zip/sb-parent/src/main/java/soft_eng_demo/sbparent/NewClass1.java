package soft_eng_demo.sbparent;


public class NewClass1 {
}
