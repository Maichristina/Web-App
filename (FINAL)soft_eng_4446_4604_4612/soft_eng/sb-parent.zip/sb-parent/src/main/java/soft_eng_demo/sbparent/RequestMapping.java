package soft_eng_demo.sbparent;

public @interface RequestMapping {

	String value();

}
