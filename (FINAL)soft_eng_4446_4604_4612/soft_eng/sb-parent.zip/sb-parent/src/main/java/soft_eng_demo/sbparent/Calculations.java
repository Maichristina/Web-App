package soft_eng_demo.sbparent;

public class Calculations {
	
	Student finalgrade = new Student( );
	Student examgrade = new Student();
	Student projectgrade = new Student ();

}
